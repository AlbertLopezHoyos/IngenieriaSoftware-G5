
package Interfaz;

import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.JOptionPane;
import javax.swing.UIManager;


public class frmLogin extends javax.swing.JFrame {


    public frmLogin() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jbtnRegistrate = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jtxtUsuario = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jpswClave = new javax.swing.JPasswordField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jbtnIngresar = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(31, 33, 36));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI Light", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 153, 153));
        jLabel2.setText("Iniciar Sesion");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 40, 220, -1));

        jbtnRegistrate.setBackground(new java.awt.Color(61, 105, 158));
        jbtnRegistrate.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        jbtnRegistrate.setForeground(new java.awt.Color(204, 204, 204));
        jbtnRegistrate.setText("Registrate");
        jbtnRegistrate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnRegistrateActionPerformed(evt);
            }
        });
        jPanel1.add(jbtnRegistrate, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 530, 230, 40));

        jSeparator1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 300, 260, -1));

        jtxtUsuario.setBackground(new java.awt.Color(31, 33, 36));
        jtxtUsuario.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jtxtUsuario.setForeground(new java.awt.Color(204, 204, 204));
        jtxtUsuario.setBorder(null);
        jPanel1.add(jtxtUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 270, 220, 40));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 400, 260, 20));

        jpswClave.setBackground(new java.awt.Color(31, 33, 36));
        jpswClave.setForeground(new java.awt.Color(204, 204, 204));
        jpswClave.setBorder(null);
        jPanel1.add(jpswClave, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 370, 220, 40));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/businessman.png"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, 60, 30));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/security.png"))); // NOI18N
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 360, 30, 50));

        jLabel4.setBackground(new java.awt.Color(204, 204, 204));
        jLabel4.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setText("Usuario");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, -1, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 204, 204));
        jLabel5.setText("Contraseña");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 90, -1));

        jbtnIngresar.setBackground(new java.awt.Color(49, 87, 44));
        jbtnIngresar.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        jbtnIngresar.setForeground(new java.awt.Color(204, 204, 204));
        jbtnIngresar.setText("Ingresar");
        jbtnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnIngresarActionPerformed(evt);
            }
        });
        jPanel1.add(jbtnIngresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 470, 230, 40));

        jTextField1.setEditable(false);
        jTextField1.setBackground(new java.awt.Color(31, 33, 36));
        jTextField1.setForeground(new java.awt.Color(31, 33, 36));
        jTextField1.setBorder(null);
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 90, 130));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Imagen de WhatsApp 2024-04-24 a las 23.16.35_a8a721ea.jpg"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, -1, 120));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 600));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Imagen de WhatsApp 2024-04-24 a las 20.44.32_32ef3539-min (1).jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 0, 650, 600));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnRegistrateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnRegistrateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnRegistrateActionPerformed

    private void jbtnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnIngresarActionPerformed
      
        String usuario = jtxtUsuario.getText();
       String clave = jpswClave.getText();
       
        if (usuario.isEmpty() || clave.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Uno de los espacios esta vacio");

               } else {
            if (usuario.equals("Administrador") && clave.equals("Ingenieriasistemas")) { // verifica si coinciden
                JOptionPane.showMessageDialog(null, "Bienvenido administrador");  // si cumplen
                Sistema bb = new Sistema();
                bb.setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Uno de los espacios escritos es incorrecto"); // si hay error
            }

        }
       
       
       
       
       
       
       
    }//GEN-LAST:event_jbtnIngresarActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed


    public static void main(String args[]) {
         FlatLightLaf.setup();
        UIManager.put("Button.arc", 50);           // ajustar la apariencia de los botones usando FlatLightLaf
        UIManager.put("TextComponent.arc", 50);

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton jbtnIngresar;
    private javax.swing.JButton jbtnRegistrate;
    private javax.swing.JPasswordField jpswClave;
    private javax.swing.JTextField jtxtUsuario;
    // End of variables declaration//GEN-END:variables
}
