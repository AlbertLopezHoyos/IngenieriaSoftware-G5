package Clases;

public class Bebida extends Producto {

    public Bebida(String nombre, double precioUnitario) {
        super(nombre, precioUnitario);

    }
}
