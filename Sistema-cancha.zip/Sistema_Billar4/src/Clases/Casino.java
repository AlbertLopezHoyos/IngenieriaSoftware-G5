package Clases;

public class Casino extends Comida {
    
    public Casino () {
    super ("Casino", 2.00);
    }
}
