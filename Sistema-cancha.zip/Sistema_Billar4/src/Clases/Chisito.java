package Clases;

public class Chisito extends Comida {
    
    public Chisito () {
    super ("Chisito",1.50);    
    }
}
