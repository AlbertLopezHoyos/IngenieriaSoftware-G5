package Clases;

public class Cielo extends Bebida {

    public Cielo() {
        super("Cielo",1.50);
    }
}
