package Clases;

public class CocaCola extends Bebida {

    public CocaCola() {
        super("Coca Cola",3.00);
    }
}
