package Clases;

public class Comida extends Producto{
    
    private String nombre;
    private double precioUnitario;
    private int cantidad;
    private  static double totalPagar = 0.0;
    
    public Comida(String nombre, double precioUnitario) {
        super (nombre, precioUnitario);
        this.nombre = nombre;
        this.precioUnitario = precioUnitario;
        this.cantidad = 0;
    } 
   
    public String getNombre() {
        return nombre;
    }
    public double getPrecioUnitario(){
        return precioUnitario;
    }
    public int getCantidad() {
        return cantidad;
    }
    public void aumentarCantidad() {
        cantidad++;
//        actualizar el total cada vez que se aumente la cantidad
        totalPagar = totalPagar + precioUnitario;
    }
    public double getPrecioTotal(){
        return cantidad * precioUnitario;
    }
    public  static double getTotalPagar(){
        return totalPagar;
    }
    public static void resetTotalPagar() {
    totalPagar = 0.0;
}  
}
