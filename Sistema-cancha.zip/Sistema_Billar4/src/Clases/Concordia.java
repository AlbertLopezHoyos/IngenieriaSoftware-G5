package Clases;

public class Concordia extends Bebida {

    public Concordia() {
        super("Concordia",1.00);
    }
}
