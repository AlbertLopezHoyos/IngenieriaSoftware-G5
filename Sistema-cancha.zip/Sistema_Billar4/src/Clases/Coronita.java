package Clases;

public class Coronita extends Bebida {

    public Coronita() {
        super("Coronita",4.00);
    }
}
