
package Clases;

public class Cuates extends Comida {
    
    public Cuates () {
    super ("Cuates", 1.00);
    } 
}
