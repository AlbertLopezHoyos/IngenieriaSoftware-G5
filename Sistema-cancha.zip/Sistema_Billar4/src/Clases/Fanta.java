package Clases;

public class Fanta extends Bebida{
 public Fanta() {
        super("Fanta",3.00);
    }
}
