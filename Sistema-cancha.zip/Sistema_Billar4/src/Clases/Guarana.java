package Clases;

public class Guarana extends Bebida {
 public Guarana() {
        super("Guarana",2.50);
    }
}
