package Clases;

public class InkaCola extends Bebida {

    public InkaCola() {
        super("Inka Cola",3.00);
    }

}
