
package Clases;

public class Lays extends Comida {
    
    public Lays () {
    super ("Lays", 1.50);
    }
}
