package Clases;

public class Mesa {

    private boolean mesaOcupada ;
    
    public void setMesaOcupada(boolean mesaOcupada){
        this.mesaOcupada = mesaOcupada;
    }
    public void isMesaOcupada(boolean mesaOcupada){
      this.mesaOcupada = mesaOcupada;
       
    }
}
