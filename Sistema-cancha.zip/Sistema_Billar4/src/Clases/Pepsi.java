package Clases;

public class Pepsi extends Bebida {

    public Pepsi() {
        super("Pepsi",2.50);
    }
}
