package Clases;

public class Pilsen extends Bebida {
  public Pilsen() {
        super("Pilsen",6.50);
    }
}
