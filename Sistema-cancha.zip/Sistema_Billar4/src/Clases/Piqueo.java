
package Clases;

public class Piqueo extends Comida {
    
    public Piqueo () {
    super ("Piqueo", 1.80);
    }
}
