
package Clases;

public class Ritz extends Comida {
    
    public Ritz () {
    super ("Ritz", 1.50);
    }
}
