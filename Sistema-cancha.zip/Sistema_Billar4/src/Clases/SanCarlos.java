package Clases;

public class SanCarlos extends Bebida {
 public SanCarlos() {
        super("San Carlos",1.00);
    }
}
