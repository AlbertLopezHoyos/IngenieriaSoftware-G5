package Clases;

public class Sebena extends Bebida {

    public Sebena() {
        super("7 Up",2.00);
    }
}
