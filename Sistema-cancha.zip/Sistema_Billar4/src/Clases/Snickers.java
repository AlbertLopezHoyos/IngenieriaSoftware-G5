
package Clases;

public class Snickers extends Comida {
    
    public Snickers () {
    super ("Snickers", 5.00);
    }
}
