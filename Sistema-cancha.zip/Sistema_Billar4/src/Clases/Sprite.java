package Clases;

public class Sprite extends Bebida {

    public Sprite() {
        super("Sprite",3.00);
    }
}
