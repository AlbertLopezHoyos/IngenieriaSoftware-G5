
package Clases;

public class Sublime extends Comida {
    
    public Sublime () {
    super ("Sublime", 2.00);
    }
}
