
package Clases;

public class Trululu extends Comida {
    
    public Trululu () {
    super ("Trululu", 1.80);
    }
}
