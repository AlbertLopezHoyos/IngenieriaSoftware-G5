package Interfaz;

import Clases.*;
import static Interfaz.Mesa_4.jtblTabla1;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;

import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.UIManager;

public class Mesa_4 extends javax.swing.JFrame {

    private double precio = 0.0;
    private Timer timer;
    private int tiempoRestanteEnSegundos;
    private static boolean mesaOcupada = false;

    public Mesa_4() {
        initComponents();
        DefaultTableModel tablaM1;
        String cabeceraM1[] = {"Producto", "Cantidad", "Precio Unitario", "Precio Total"};
        String dataM1[][] = {};

// ... (código existente)
// En el lugar apropiado de tu código, probablemente dentro de un método o constructor:
        tablaM1 = new DefaultTableModel(dataM1, cabeceraM1);
        jtblTabla1.setModel(tablaM1);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel43 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jLabel47 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        pRefrigerio = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        Jbregresar = new javax.swing.JButton();
        pPedidos = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jButton19 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtblTabla1 = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jcbxTiempo = new javax.swing.JComboBox<>();
        jblTiempoRestante = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jtxtCostoTiempo = new javax.swing.JTextField();
        jbtnIniciarTiempo = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jtxtTotalPagar = new javax.swing.JTextField();
        jPanel10 = new javax.swing.JPanel();
        jLabel48 = new javax.swing.JLabel();
        jtxtTotalPagarP1 = new javax.swing.JTextField();
        jbtnEliminar = new javax.swing.JButton();
        jbtnSumar = new javax.swing.JButton();
        jLabel32 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jbtnAgregarInkaCola = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jbtnAgregarSebena = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jbtnAgregarPepsi = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        jbtnAgregarFanta = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jbtnAgregarLays1 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jButton35 = new javax.swing.JButton();
        jbtnAgregarChisito = new javax.swing.JButton();
        jLabel57 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jButton28 = new javax.swing.JButton();
        jbtnAgregarCocaCola = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        jbtnAgregarGuarana = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jbtnAgregarSprite = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel40 = new javax.swing.JLabel();
        jbtnAgregarConcordia = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jLabel61 = new javax.swing.JLabel();
        jbtnAgregarCuates = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        jButton29 = new javax.swing.JButton();
        jLabel62 = new javax.swing.JLabel();
        jbtnAgregarSublime = new javax.swing.JButton();
        jButton31 = new javax.swing.JButton();
        jbtnAgregarSanCarlos = new javax.swing.JButton();
        jbtnAgregarCielo = new javax.swing.JButton();
        jLabel49 = new javax.swing.JLabel();
        jButton14 = new javax.swing.JButton();
        jbtnAgregarCoronita = new javax.swing.JButton();
        jLabel50 = new javax.swing.JLabel();
        jButton15 = new javax.swing.JButton();
        jLabel51 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jbtnAgregarPilsen = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jLabel63 = new javax.swing.JLabel();
        jbtnAgregarSnickers = new javax.swing.JButton();
        jButton30 = new javax.swing.JButton();
        jLabel64 = new javax.swing.JLabel();
        jbtnAgregarTrululu = new javax.swing.JButton();
        jButton32 = new javax.swing.JButton();
        jLabel46 = new javax.swing.JLabel();
        jButton13 = new javax.swing.JButton();
        jLabel30 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel71 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        jLabel43.setBackground(new java.awt.Color(0, 0, 0));
        jLabel43.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel43.setText("S/1.00");

        jButton2.setText("R");

        jRadioButton1.setText("jRadioButton1");

        jLabel47.setBackground(new java.awt.Color(255, 255, 255));
        jLabel47.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setText(" Total");

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("ANTOJOS PARA DISFRITAR MEJOR DEL JUEGO");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(102, 153, 0));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(135, 109, 135));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel59.setBackground(new java.awt.Color(0, 0, 0));
        jLabel59.setFont(new java.awt.Font("SimSun-ExtB", 1, 48)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(135, 109, 135));
        jLabel59.setText("4");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jLabel59)
                .addGap(19, 19, 19))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addGap(0, 6, Short.MAX_VALUE)
                .addComponent(jLabel59))
        );

        jPanel7.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, -1, -1));

        jPanel2.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 83, 149, 86));

        jLabel60.setBackground(new java.awt.Color(0, 0, 0));
        jLabel60.setFont(new java.awt.Font("SimSun-ExtB", 1, 48)); // NOI18N
        jLabel60.setText("MESA:");
        jPanel2.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(41, 16, -1, -1));

        Jbregresar.setText("VER MESAS");
        Jbregresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JbregresarActionPerformed(evt);
            }
        });
        jPanel2.add(Jbregresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 60, 140, 42));

        pPedidos.setBackground(new java.awt.Color(255, 255, 255));
        pPedidos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pPedidosMouseClicked(evt);
            }
        });
        pPedidos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel29.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel29.setText("Pedidos");
        pPedidos.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, 50, 20));

        jPanel2.add(pPedidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 120, 120, 20));
        jPanel2.add(jButton19, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 110, 140, 40));

        jPanel6.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 400, 190));

        jtblTabla1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jtblTabla1);

        jPanel6.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, 520, 400));

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jcbxTiempo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "01 minutos", "30 minutos", "01 hora", "01 h y 30 min", "02 hora", "02 h y 30 min", "03 hora", "03 h y 30 min", "04 hora", "04 h y 30 min", "05 hora", "05 h y 30 min", "06 hora" }));
        jcbxTiempo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcbxTiempoActionPerformed(evt);
            }
        });
        jPanel4.add(jcbxTiempo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 150, 50));

        jblTiempoRestante.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Tiempo Restante", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Segoe UI Light", 0, 12))); // NOI18N
        jPanel4.add(jblTiempoRestante, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, 150, 50));

        jLabel31.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        jLabel31.setText("Costo por Tiempo:");
        jPanel4.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 180, 50));

        jtxtCostoTiempo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtCostoTiempoActionPerformed(evt);
            }
        });
        jPanel4.add(jtxtCostoTiempo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 150, 160, 30));

        jbtnIniciarTiempo.setText("INICIAR");
        jbtnIniciarTiempo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnIniciarTiempoActionPerformed(evt);
            }
        });
        jPanel4.add(jbtnIniciarTiempo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 330, 40));

        jPanel6.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 400, 200));

        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Pago Total", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Segoe UI Light", 0, 12))); // NOI18N
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("S/");
        jPanel9.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 20, 35));

        jButton5.setText("PAGO");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, 117, 36));
        jPanel9.add(jtxtTotalPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, 290, 30));

        jPanel6.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 400, 110));

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(), "Monto a Pagar de Pedidos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Light", 0, 12))); // NOI18N
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel48.setBackground(new java.awt.Color(255, 255, 255));
        jLabel48.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel48.setText("S/.");
        jPanel10.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 30, -1));

        jtxtTotalPagarP1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtTotalPagarP1ActionPerformed(evt);
            }
        });
        jPanel10.add(jtxtTotalPagarP1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 240, -1));

        jbtnEliminar.setText("ELIMINAR");
        jbtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnEliminarActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 40, 90, 40));

        jbtnSumar.setText("SUMAR");
        jbtnSumar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnSumarActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnSumar, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 40, 90, 40));

        jPanel6.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 430, 520, 110));

        jLabel32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/120214fdb6d8969745da38d4ac432adb.jpg"))); // NOI18N
        jPanel6.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -20, 980, 600));

        jPanel3.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 7, 980, 560));

        pRefrigerio.addTab("Mesas", jPanel3);

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/WhatsApp_Image_2023-10-12_at_10.06.42_PM-removebg-preview (2).png"))); // NOI18N
        jPanel5.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, -1, 80));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/WhatsApp_Image_2023-10-12_at_11.30.39_PM-removebg-preview (2).png"))); // NOI18N
        jPanel5.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 410, 50, 80));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/WhatsApp_Image_2023-10-12_at_11.34.28_PM-removebg-preview (2).png"))); // NOI18N
        jPanel5.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 420, 30, -1));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/PLays-fotor-bg-remover-2023101221232 (2).png"))); // NOI18N
        jPanel5.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 120, 100, 80));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/86564017b7adaaa1786331bf27480db9-removebg-preview (2)_1.png"))); // NOI18N
        jPanel5.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 120, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/R__1_-removebg-preview (1)_1.png"))); // NOI18N
        jPanel5.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(535, 120, 70, 80));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/IncaCola500ml5e46dfd2d5914-removebg-preview (4)_1.png"))); // NOI18N
        jPanel5.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 70, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/sprite-removebg-preview (3)_2.png"))); // NOI18N
        jPanel5.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 260, -1, -1));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/WhatsApp_Image_2023-10-12_at_9.57.56_PM__1_-removebg-preview (1).png"))); // NOI18N
        jPanel5.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 270, -1, -1));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/WhatsApp_Image_2023-10-15_at_7.37.01_PM-removebg-preview (2).png"))); // NOI18N
        jPanel5.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 270, -1, -1));

        jbtnAgregarInkaCola.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarInkaCola.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarInkaCola.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarInkaCola.setText("Agregar a Cuenta");
        jbtnAgregarInkaCola.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarInkaColaActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarInkaCola, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 120, -1));

        jLabel17.setBackground(new java.awt.Color(0, 0, 0));
        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel17.setText("S/.3.00");
        jPanel5.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, 60, -1));

        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 140, 140));

        jLabel18.setBackground(new java.awt.Color(0, 0, 0));
        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel18.setText("S/.3.00");
        jPanel5.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, 60, -1));

        jLabel35.setBackground(new java.awt.Color(0, 0, 0));
        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel35.setText("S/.2.00");
        jPanel5.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 200, 60, -1));

        jbtnAgregarSebena.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarSebena.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarSebena.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarSebena.setText("Agregar a Cuenta");
        jbtnAgregarSebena.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarSebenaActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarSebena, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 120, -1));

        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 110, 140, 140));

        jbtnAgregarPepsi.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarPepsi.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarPepsi.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarPepsi.setText("Agregar a Cuenta");
        jbtnAgregarPepsi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarPepsiActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarPepsi, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 220, 120, -1));

        jLabel21.setBackground(new java.awt.Color(0, 0, 0));
        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel21.setText("S/.2.50");
        jPanel5.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 200, 60, -1));

        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 110, 140, 140));

        jLabel22.setBackground(new java.awt.Color(0, 0, 0));
        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel22.setText("S/3.00");
        jPanel5.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 200, 60, -1));

        jbtnAgregarFanta.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarFanta.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarFanta.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarFanta.setText("Agregar a Cuenta");
        jbtnAgregarFanta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarFantaActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarFanta, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 220, 120, -1));

        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 110, 140, 140));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pro_d82e32585f7e3d0650f803316a395eed-removebg-preview+(1).png"))); // NOI18N
        jPanel5.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 270, -1, -1));

        jLabel65.setText("S/.1.50");
        jPanel5.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 200, -1, -1));

        jbtnAgregarLays1.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarLays1.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarLays1.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarLays1.setText("Agregar a Cuenta");
        jbtnAgregarLays1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarLays1ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarLays1, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 220, 120, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/R__3_-removebg-preview (2)_1.png"))); // NOI18N
        jPanel5.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 420, -1, -1));

        jButton35.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton35ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton35, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 110, 140, 140));

        jbtnAgregarChisito.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarChisito.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarChisito.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarChisito.setText("Agregar a Cuenta");
        jbtnAgregarChisito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarChisitoActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarChisito, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 220, 120, -1));

        jLabel57.setText("S/.1.50");
        jPanel5.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 200, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chisito-fotor-bg-remover-20231012211035 (1).png"))); // NOI18N
        jPanel5.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 130, -1, -1));

        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/imgbin-coca-cola-zero-soft-drink-diet-coke-coca-cola-PgBXgvUPi0udda0Z45PS5XcXu_t-removebg-preview (2)_2.png"))); // NOI18N
        jPanel5.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 270, -1, -1));

        jButton28.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton28, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 110, 140, 140));

        jbtnAgregarCocaCola.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarCocaCola.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarCocaCola.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarCocaCola.setText("Agregar a Cuenta");
        jbtnAgregarCocaCola.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarCocaColaActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarCocaCola, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 120, -1));

        jLabel23.setBackground(new java.awt.Color(0, 0, 0));
        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel23.setText("S/.3.00");
        jPanel5.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 350, 60, -1));

        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 140, 140));

        jLabel25.setBackground(new java.awt.Color(0, 0, 0));
        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel25.setText("S/.2.50");
        jPanel5.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 350, 60, -1));

        jbtnAgregarGuarana.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarGuarana.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarGuarana.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarGuarana.setText("Agregar a Cuenta");
        jbtnAgregarGuarana.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarGuaranaActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarGuarana, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 370, 120, -1));

        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 140, 140));

        jLabel38.setBackground(new java.awt.Color(0, 0, 0));
        jLabel38.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel38.setText("S/.3.00");
        jPanel5.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 350, 60, -1));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/CHOCOLATE-38-GR-X-20-UND-SUBLIME-SONRISA-fotor-bg-remover-20231012211732.png"))); // NOI18N
        jPanel5.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 280, -1, -1));

        jbtnAgregarSprite.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarSprite.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarSprite.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarSprite.setText("Agregar a Cuenta");
        jbtnAgregarSprite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarSpriteActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarSprite, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 370, 120, -1));

        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 260, 140, 140));

        jLabel40.setBackground(new java.awt.Color(0, 0, 0));
        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel40.setText("S/.1.00");
        jPanel5.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 350, 60, -1));

        jbtnAgregarConcordia.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarConcordia.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarConcordia.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarConcordia.setText("Agregar a Cuenta");
        jbtnAgregarConcordia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarConcordiaActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarConcordia, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 370, 120, -1));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/R__4_-removebg-preview (1).png"))); // NOI18N
        jPanel5.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 420, -1, 70));

        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 260, 140, 140));

        jLabel61.setText("S/.1.00");
        jPanel5.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 350, -1, -1));

        jbtnAgregarCuates.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarCuates.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarCuates.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarCuates.setText("Agregar a Cuenta");
        jbtnAgregarCuates.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarCuatesActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarCuates, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 370, 120, -1));

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cusqueña-roja-Gourmeat-removebg-preview (1)_1.png"))); // NOI18N
        jPanel5.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 410, 60, -1));

        jButton29.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton29, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 260, 140, 140));

        jLabel62.setText("S/.2.00");
        jPanel5.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 350, -1, -1));

        jbtnAgregarSublime.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarSublime.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarSublime.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarSublime.setText("Agregar a Cuenta");
        jbtnAgregarSublime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarSublimeActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarSublime, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 370, 120, -1));

        jButton31.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton31, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 260, 140, 140));

        jbtnAgregarSanCarlos.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarSanCarlos.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarSanCarlos.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarSanCarlos.setText("Agregar a Cuenta");
        jbtnAgregarSanCarlos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarSanCarlosActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarSanCarlos, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 520, 120, -1));

        jbtnAgregarCielo.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarCielo.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarCielo.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarCielo.setText("Agregar a Cuenta");
        jbtnAgregarCielo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarCieloActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarCielo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 520, 120, -1));

        jLabel49.setBackground(new java.awt.Color(0, 0, 0));
        jLabel49.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel49.setText("S/1.50");
        jPanel5.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 500, 60, -1));

        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 410, 140, 140));

        jbtnAgregarCoronita.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarCoronita.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarCoronita.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarCoronita.setText("Agregar a Cuenta");
        jbtnAgregarCoronita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarCoronitaActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarCoronita, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 520, 120, -1));

        jLabel50.setBackground(new java.awt.Color(0, 0, 0));
        jLabel50.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel50.setText("S/.4.00");
        jPanel5.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 500, 60, -1));

        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 410, 140, 140));

        jLabel51.setBackground(new java.awt.Color(0, 0, 0));
        jLabel51.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel51.setText("S/.6.50");
        jPanel5.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 500, 60, -1));

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/gomitas-trululu-1_1800x1800-fotor-bg-remover-20231012212359 (1).png"))); // NOI18N
        jPanel5.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 420, -1, -1));

        jbtnAgregarPilsen.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarPilsen.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarPilsen.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarPilsen.setText("Agregar a Cuenta");
        jbtnAgregarPilsen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarPilsenActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarPilsen, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 520, 120, -1));

        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 410, 140, 140));

        jLabel63.setText("S/.5.00");
        jPanel5.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 500, -1, -1));

        jbtnAgregarSnickers.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarSnickers.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarSnickers.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarSnickers.setText("Agregar a Cuenta");
        jbtnAgregarSnickers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarSnickersActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarSnickers, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 520, 120, -1));

        jButton30.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton30ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton30, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 410, 140, 140));

        jLabel64.setText("S/.1.80");
        jPanel5.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 500, -1, -1));

        jbtnAgregarTrululu.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarTrululu.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarTrululu.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarTrululu.setText("Agregar a Cuenta");
        jbtnAgregarTrululu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarTrululuActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnAgregarTrululu, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 520, 120, -1));

        jButton32.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton32ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton32, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 410, 140, 140));

        jLabel46.setBackground(new java.awt.Color(0, 0, 0));
        jLabel46.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel46.setText("S/1.00");
        jPanel5.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 500, 60, -1));

        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, 140, 140));

        jLabel30.setBackground(new java.awt.Color(0, 0, 0));
        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel30.setText("S/1.00");
        jPanel5.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 500, 60, -1));

        jLabel44.setBackground(new java.awt.Color(0, 0, 0));
        jLabel44.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel44.setText("S/1.00");
        jPanel5.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 500, 60, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel1MouseClicked(evt);
            }
        });
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel2.setText("REGRESAR");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, -10, -1, 40));

        jPanel5.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 30, 190, 20));

        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel5.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 20, 210, 40));
        jPanel5.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 1020, 20));

        jLabel71.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/snack.png"))); // NOI18N
        jPanel5.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 90, 80));

        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/can.png"))); // NOI18N
        jPanel5.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 50, 40));

        jLabel34.setFont(new java.awt.Font("Segoe UI Light", 1, 24)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("Bebidas");
        jPanel5.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 140, 40));

        jLabel36.setFont(new java.awt.Font("Segoe UI Light", 1, 24)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("y");
        jPanel5.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 20, 30, 40));

        jLabel37.setFont(new java.awt.Font("Segoe UI Light", 1, 24)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("Snacks");
        jPanel5.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 20, 140, 40));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/120214fdb6d8969745da38d4ac432adb.jpg"))); // NOI18N
        jPanel5.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 990, 580));

        pRefrigerio.addTab("Refrigerio", jPanel5);

        getContentPane().add(pRefrigerio, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -36, 980, 600));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public  static void setMesaOcupada(boolean ocupada) {
        mesaOcupada = ocupada;
    }

    public static boolean isMesaOcupada() {
        return mesaOcupada;
    }
    
    private void JbregresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JbregresarActionPerformed

        // Regresar al frame principal
        Sistema Ini = new Sistema();
        Ini.setVisible(true);
        dispose();

    }//GEN-LAST:event_JbregresarActionPerformed

    private void jtxtTotalPagarP1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtTotalPagarP1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtTotalPagarP1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jbtnAgregarInkaColaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarInkaColaActionPerformed
        Bebida inkacola = new InkaCola();
        inkacola.aumentarCantidad();
        agregarProductoTabla(inkacola);
    }//GEN-LAST:event_jbtnAgregarInkaColaActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed

    }//GEN-LAST:event_jButton6ActionPerformed

    private void jbtnAgregarSebenaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarSebenaActionPerformed
        Bebida sebena = new Sebena();
        sebena.aumentarCantidad();
        agregarProductoTabla(sebena);
    }//GEN-LAST:event_jbtnAgregarSebenaActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jbtnAgregarPepsiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarPepsiActionPerformed
        Bebida pepsi = new Pepsi();
        pepsi.aumentarCantidad();
        agregarProductoTabla(pepsi);
    }//GEN-LAST:event_jbtnAgregarPepsiActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jbtnAgregarFantaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarFantaActionPerformed
        Bebida fanta = new Fanta();
        fanta.aumentarCantidad();
        agregarProductoTabla(fanta);
    }//GEN-LAST:event_jbtnAgregarFantaActionPerformed

    private void jButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton35ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton35ActionPerformed

    private void jbtnAgregarLays1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarLays1ActionPerformed
        Comida lays = new Lays();
        lays.aumentarCantidad();
        agregarProductoTabla(lays);
    }//GEN-LAST:event_jbtnAgregarLays1ActionPerformed

    private void jbtnAgregarChisitoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarChisitoActionPerformed
        Comida chisito = new Chisito();
        chisito.aumentarCantidad();
        agregarProductoTabla(chisito);
    }//GEN-LAST:event_jbtnAgregarChisitoActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jbtnAgregarCocaColaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarCocaColaActionPerformed
        Bebida cocacola = new CocaCola();
        cocacola.aumentarCantidad();
        agregarProductoTabla(cocacola);
    }//GEN-LAST:event_jbtnAgregarCocaColaActionPerformed

    private void jbtnAgregarGuaranaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarGuaranaActionPerformed
        Bebida guarana = new Guarana();
        guarana.aumentarCantidad();
        agregarProductoTabla(guarana);
    }//GEN-LAST:event_jbtnAgregarGuaranaActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jbtnAgregarSpriteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarSpriteActionPerformed
        Bebida sprite = new Sprite();
        sprite.aumentarCantidad();
        agregarProductoTabla(sprite);
    }//GEN-LAST:event_jbtnAgregarSpriteActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jbtnAgregarConcordiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarConcordiaActionPerformed
        Bebida concordia = new Concordia();
        concordia.aumentarCantidad();
        agregarProductoTabla(concordia);
    }//GEN-LAST:event_jbtnAgregarConcordiaActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton29ActionPerformed

    private void jbtnAgregarCuatesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarCuatesActionPerformed
        Comida cuates = new Cuates();
        cuates.aumentarCantidad();
        agregarProductoTabla(cuates);
    }//GEN-LAST:event_jbtnAgregarCuatesActionPerformed

    private void jbtnAgregarSublimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarSublimeActionPerformed
        Comida sublime = new Sublime();
        sublime.aumentarCantidad();
        agregarProductoTabla(sublime);
    }//GEN-LAST:event_jbtnAgregarSublimeActionPerformed

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton31ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jbtnAgregarSanCarlosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarSanCarlosActionPerformed
        Bebida sancarlos = new SanCarlos();
        sancarlos.aumentarCantidad();
        agregarProductoTabla(sancarlos);
    }//GEN-LAST:event_jbtnAgregarSanCarlosActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jbtnAgregarCieloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarCieloActionPerformed
        Bebida cielo = new Cielo();
        cielo.aumentarCantidad();
        agregarProductoTabla(cielo);
    }//GEN-LAST:event_jbtnAgregarCieloActionPerformed

    private void jbtnAgregarCoronitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarCoronitaActionPerformed
        Bebida coronita = new Coronita();
        coronita.aumentarCantidad();
        agregarProductoTabla(coronita);
    }//GEN-LAST:event_jbtnAgregarCoronitaActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jbtnAgregarPilsenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarPilsenActionPerformed
        Bebida pilsen = new Pilsen();
        pilsen.aumentarCantidad();
        agregarProductoTabla(pilsen);
    }//GEN-LAST:event_jbtnAgregarPilsenActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton30ActionPerformed

    private void jbtnAgregarSnickersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarSnickersActionPerformed
        Comida snickers = new Snickers();
        snickers.aumentarCantidad();
        agregarProductoTabla(snickers);
    }//GEN-LAST:event_jbtnAgregarSnickersActionPerformed

    private void jbtnAgregarTrululuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarTrululuActionPerformed
        Comida trululu = new Trululu();
        trululu.aumentarCantidad();
        agregarProductoTabla(trululu);
    }//GEN-LAST:event_jbtnAgregarTrululuActionPerformed

    private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton32ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton32ActionPerformed

    private void jbtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnEliminarActionPerformed

    }//GEN-LAST:event_jbtnEliminarActionPerformed

    private void pPedidosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pPedidosMouseClicked
        pRefrigerio.setSelectedIndex(1);
    }//GEN-LAST:event_pPedidosMouseClicked

    private void jtxtCostoTiempoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtCostoTiempoActionPerformed

    }//GEN-LAST:event_jtxtCostoTiempoActionPerformed

    private void jbtnIniciarTiempoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnIniciarTiempoActionPerformed
     
        // Verificar si se ha seleccionado un tiempo
        if (jcbxTiempo.getSelectedIndex() > 0) {
            String tiempoSeleccionado = jcbxTiempo.getSelectedItem().toString();

            mesaOcupada = true;
            // Calcular el precio y mostrarlo en la caja de texto
            precio = obtenerPrecioPorTiempo(tiempoSeleccionado);
            jtxtCostoTiempo.setText(String.valueOf(precio));

            // Obtener la duración en segundos y mostrar el tiempo restante en el label
            tiempoRestanteEnSegundos = obtenerDuracionEnSegundos(tiempoSeleccionado);
            mostrarTiempoRestante(tiempoRestanteEnSegundos);

            // Iniciar el temporizador
            timer = new Timer(1000, e -> {
                tiempoRestanteEnSegundos--;

                if (tiempoRestanteEnSegundos >= 0) {
                    mostrarTiempoRestante(tiempoRestanteEnSegundos);
                } else {
                    mesaOcupada = false;
                    timer.stop();
                    // Aquí puedes realizar alguna acción adicional cuando se agote el tiempo
                }
            });
            timer.start();
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un tiempo antes de iniciar.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jbtnIniciarTiempoActionPerformed

    private void jcbxTiempoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcbxTiempoActionPerformed
        // Obtener el tiempo seleccionado como cadena desde el combobox
        String tiempoSeleccionado = jcbxTiempo.getSelectedItem().toString();

        // Verificar si se ha seleccionado un tiempo
        if (jcbxTiempo.getSelectedIndex() > 0) {
            // Calcular el precio y mostrarlo en la caja de texto
            precio = obtenerPrecioPorTiempo(tiempoSeleccionado);
            jtxtCostoTiempo.setText(String.valueOf(precio));

            // Obtener la duración en segundos y mostrar el tiempo restante en el label
            tiempoRestanteEnSegundos = obtenerDuracionEnSegundos(tiempoSeleccionado);
            mostrarTiempoRestante(tiempoRestanteEnSegundos);
        } else {
            // Limpiar la caja de texto y el label si no se ha seleccionado ningún tiempo
            jtxtCostoTiempo.setText("");
            jblTiempoRestante.setText("");
        }
    }//GEN-LAST:event_jcbxTiempoActionPerformed

    private void jPanel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseClicked
        pRefrigerio.setSelectedIndex(0);
    }//GEN-LAST:event_jPanel1MouseClicked

    private void jbtnSumarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnSumarActionPerformed
         
            // Obtener valores de los campos de texto
            String textValor1 = jtxtTotalPagarP1.getText();
            String textValor2 = jtxtCostoTiempo.getText();

             // Verificar si los campos están vacíos y asignarles un valor predeterminado de 0 si es necesario
            double valor1 = textValor1.isEmpty() ? 0.0 : Double.parseDouble(textValor1);
            double valor2 = textValor2.isEmpty() ? 0.0 : Double.parseDouble(textValor2);

            // Realizar la suma
            double resultado = valor1 + valor2;

            // Mostrar el resultado en el campo de texto correspondiente
            jtxtTotalPagar.setText(Double.toString(resultado));
    }//GEN-LAST:event_jbtnSumarActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
     DefaultTableModel model = (DefaultTableModel) jtblTabla1.getModel();
        model.setRowCount(0); // Borra todas las filas de la tabla
        Bebida.resetTotalPagar(); // Actualiza el valor del precio total a cero
        jtxtTotalPagar.setText("0.00");   
        jtxtTotalPagarP1.setText("0.00");
        jtxtCostoTiempo.setText ("0.00");
    }//GEN-LAST:event_jButton5ActionPerformed
    // Método para mostrar el tiempo restante en formato HH:mm:ss

    private void mostrarTiempoRestante(int tiempoEnSegundos) {
        // Calcular las horas, minutos y segundos a partir del tiempo total en segundos
        int horas = tiempoEnSegundos / 3600;
        int minutos = (tiempoEnSegundos % 3600) / 60;
        int segundos = tiempoEnSegundos % 60;
        // Establecer el texto en el JLabel jblTiempoRestante con el formato HH:mm:ss 
        jblTiempoRestante.setText(String.format("%02d:%02d:%02d", horas, minutos, segundos));
    }

    private double obtenerPrecioPorTiempo(String tiempoSeleccionado) {
        switch (tiempoSeleccionado) {
            case "01 minutos":
                return 1.00;
            case "30 minutos":
                return 4.00;
            case "01 hora":
                return 8.00;
            case "01 h y 30 min":
                return 12.00;
            case "02 hora":
                return 16.00;
            case "02 h y 30 min":
                return 20.00;
            case "03 hora":
                return 24.00;
            case "03 h y 30 min":
                return 28.00;
            case "04 hora":
                return 32.00;
            case "04 h y 30 min":
                return 36.00;
            case "05 hora":
                return 40.00;
            case "05 h y 30 min":
                return 44.00;
            case "06 hora":
                return 48.00;
            default:
                return 0.0;
        }
    }

    // Método para obtener la duración en segundos basada en la opción seleccionada
    private int obtenerDuracionEnSegundos(String tiempoSeleccionado) {
        switch (tiempoSeleccionado) {
            case "01 minutos":
                return 1 * 60;
            case "30 minutos":
                return 30 * 60;
            case "01 hora":
                return 60 * 60;
            case "01 h y 30 min":
                return 90 * 60;
            case "02 hora":
                return 120 * 60;
            case "02 h y 30 min":
                return 150 * 60;
            case "03 hora":
                return 180 * 60;
            case "03 h y 30 min":
                return 210 * 60;
            case "04 hora":
                return 240 * 60;
            case "04 h y 30 min":
                return 270 * 60;
            case "05 hora":
                return 300 * 60;
            case "05 h y 30 min":
                return 330 * 60;
            case "06 hora":
                return 360 * 60;
            default:
                return 0;
        }

    }

    public void agregarProductoTabla(Producto producto) {
        String nombreProducto = producto.getNombre();
        DefaultTableModel modeloTabla = (DefaultTableModel) jtblTabla1.getModel();
        // Buscar si el producto ya existe en la tabla
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            if (nombreProducto.equals(modeloTabla.getValueAt(i, 0))) {
                // Si encontramos el producto, actualizamos cantidad, precio unitario y precio total
                int cantidadActual = (int) modeloTabla.getValueAt(i, 1);
                double precioUnitario = producto.getPrecioUnitario();
                cantidadActual++;
                double precioTotal = cantidadActual * precioUnitario;

                modeloTabla.setValueAt(cantidadActual, i, 1); // Incrementamos la cantidad
                modeloTabla.setValueAt(precioUnitario, i, 2); // Actualizamos el precio unitario
                modeloTabla.setValueAt(precioTotal, i, 3); // Actualizamos el precio total

                 // Actualizamos el total a pagar
                actualizarTotalPagar(modeloTabla);

                return; // Salimos del método ya que el producto ya fue actualizado
            }
        }

        // Si el producto no existe, lo agregamos como una nueva fila
        modeloTabla.addRow(new Object[]{nombreProducto, 1, producto.getPrecioUnitario(), producto.getPrecioTotal()});

           // Actualizamos el total a pagar
           actualizarTotalPagar(modeloTabla);

    }
    private void actualizarTotalPagar(DefaultTableModel modeloTabla) {
    double totalPagar = 0;
    for (int i = 0; i < modeloTabla.getRowCount(); i++) {
        totalPagar += (double) modeloTabla.getValueAt(i, 3); // Suma los valores de la columna de precios totales
    }
    jtxtTotalPagarP1.setText(String.valueOf(totalPagar));
}

    public static void main(String args[]) {

        FlatLightLaf.setup();
        UIManager.put("Button.arc", 50);
        UIManager.put("TextComponent.arc", 50);

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Mesa_4().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Jbregresar;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel jblTiempoRestante;
    private javax.swing.JButton jbtnAgregarChisito;
    private javax.swing.JButton jbtnAgregarCielo;
    private javax.swing.JButton jbtnAgregarCocaCola;
    private javax.swing.JButton jbtnAgregarConcordia;
    private javax.swing.JButton jbtnAgregarCoronita;
    private javax.swing.JButton jbtnAgregarCuates;
    private javax.swing.JButton jbtnAgregarFanta;
    private javax.swing.JButton jbtnAgregarGuarana;
    private javax.swing.JButton jbtnAgregarInkaCola;
    private javax.swing.JButton jbtnAgregarLays1;
    private javax.swing.JButton jbtnAgregarPepsi;
    private javax.swing.JButton jbtnAgregarPilsen;
    private javax.swing.JButton jbtnAgregarSanCarlos;
    private javax.swing.JButton jbtnAgregarSebena;
    private javax.swing.JButton jbtnAgregarSnickers;
    private javax.swing.JButton jbtnAgregarSprite;
    private javax.swing.JButton jbtnAgregarSublime;
    private javax.swing.JButton jbtnAgregarTrululu;
    private javax.swing.JButton jbtnEliminar;
    private javax.swing.JButton jbtnIniciarTiempo;
    private javax.swing.JButton jbtnSumar;
    private javax.swing.JComboBox<String> jcbxTiempo;
    public static javax.swing.JTable jtblTabla1;
    private javax.swing.JTextField jtxtCostoTiempo;
    private javax.swing.JTextField jtxtTotalPagar;
    private javax.swing.JTextField jtxtTotalPagarP1;
    private javax.swing.JPanel pPedidos;
    private javax.swing.JTabbedPane pRefrigerio;
    // End of variables declaration//GEN-END:variables
}
