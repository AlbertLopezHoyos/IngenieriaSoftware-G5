package Interfaz;

import Clases.*;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author BRYAN
 */
public class Sistema extends javax.swing.JFrame {

   
    private DefaultTableModel tableModel;
    private DefaultTableModel tableModelC;
   
      

    public Sistema() {
        DefaultTableModel tabla;
        DefaultTableModel tablaC;

        String cabecera[] = {"Accesorio", "Cantidad", "Precio Unitario", "Precio Total"};
        String cabeceraC[] = {"Accesorio", "Cantidad", "Precio Unitario", "Precio Total"};
        String data[][] = {};
        String dataC[][] = {};
        initComponents();
     
        tabla = new DefaultTableModel(data, cabecera);
        tablaC = new DefaultTableModel(data, cabecera);
        jtblTabla.setModel(tabla);
        tableModel = (DefaultTableModel) jtblTabla.getModel();
        jtblTabla1.setModel(tablaC);
        tableModelC = (DefaultTableModel) jtblTabla1.getModel();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel44 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel57 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        Salir = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        Mesas = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        Bebidas = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Snacks = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        pSnacks = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jButton18 = new javax.swing.JButton();
        jLabel77 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel85 = new javax.swing.JLabel();
        jbtnMesa1 = new javax.swing.JButton();
        jSeparator6 = new javax.swing.JSeparator();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel56 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jbtnPagar = new javax.swing.JButton();
        jLabel32 = new javax.swing.JLabel();
        jbtnAgregarInkaCola = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jLabel34 = new javax.swing.JLabel();
        jbtnAgregarSebena = new javax.swing.JButton();
        jLabel35 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jbtnAgregarPepsi = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jbtnAgregarFanta = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jbtnAgregarCocaCola = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jLabel36 = new javax.swing.JLabel();
        jbtnAgregarGuarana = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jbtnAgregarSprite = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jbtnAgregarConcordia = new javax.swing.JButton();
        jLabel40 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jLabel41 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jbtnAgregarSanCarlos = new javax.swing.JButton();
        jLabel42 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jLabel54 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jtxtTotalPagar = new javax.swing.JTextField();
        jbtnAgregarCielo = new javax.swing.JButton();
        jLabel49 = new javax.swing.JLabel();
        jButton13 = new javax.swing.JButton();
        jbtnAgregarCoronita = new javax.swing.JButton();
        jLabel50 = new javax.swing.JLabel();
        jButton14 = new javax.swing.JButton();
        jbtnAgregarPilsen = new javax.swing.JButton();
        jLabel51 = new javax.swing.JLabel();
        jButton15 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtblTabla = new javax.swing.JTable();
        jButton16 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jLabel52 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jbtnAgregarChisito = new javax.swing.JButton();
        jbtnAgregarCuates = new javax.swing.JButton();
        jbtnAgregarPiqueo = new javax.swing.JButton();
        jbtnAgregarCasino = new javax.swing.JButton();
        jbtnAgregarLays = new javax.swing.JButton();
        jbtnAgregarSublime = new javax.swing.JButton();
        jComboBox4 = new javax.swing.JComboBox<>();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jButton29 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jComboBox5 = new javax.swing.JComboBox<>();
        jComboBox7 = new javax.swing.JComboBox<>();
        jComboBox6 = new javax.swing.JComboBox<>();
        jButton31 = new javax.swing.JButton();
        jbtnbutton = new javax.swing.JButton();
        jComboBox2 = new javax.swing.JComboBox<>();
        jButton36 = new javax.swing.JButton();
        jButton35 = new javax.swing.JButton();
        jtxtTotalPagar1 = new javax.swing.JTextField();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jtblTabla1 = new javax.swing.JTable();
        jLabel73 = new javax.swing.JLabel();
        jbtnPagar1 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();

        jLabel57.setText("jLabel57");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 44, 34));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Salir.setBackground(new java.awt.Color(12, 20, 11));
        Salir.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                SalirMouseMoved(evt);
            }
        });
        Salir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SalirMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SalirMouseExited(evt);
            }
        });
        Salir.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Segoe UI Light", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Salir");
        Salir.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, -10, 60, 80));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/exit.png"))); // NOI18N
        Salir.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, -30, 50, 120));

        jPanel2.add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 480, 230, 50));

        Mesas.setBackground(new java.awt.Color(12, 20, 11));
        Mesas.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                MesasMouseMoved(evt);
            }
        });
        Mesas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MesasMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                MesasMouseExited(evt);
            }
        });
        Mesas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel26.setFont(new java.awt.Font("Segoe UI Light", 1, 24)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Campos");
        Mesas.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, 90, 40));

        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/football-field.png"))); // NOI18N
        Mesas.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 60, 40));

        jPanel2.add(Mesas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 230, 60));

        Bebidas.setBackground(new java.awt.Color(12, 20, 11));
        Bebidas.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                BebidasMouseMoved(evt);
            }
        });
        Bebidas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BebidasMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BebidasMouseExited(evt);
            }
        });
        Bebidas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/file.png"))); // NOI18N
        Bebidas.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 50, 40));

        jLabel6.setFont(new java.awt.Font("Segoe UI Light", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Detalle");
        Bebidas.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, 140, 40));

        jPanel2.add(Bebidas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, -1, 60));

        Snacks.setBackground(new java.awt.Color(12, 20, 11));
        Snacks.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                SnacksMouseMoved(evt);
            }
        });
        Snacks.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SnacksMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SnacksMouseExited(evt);
            }
        });
        Snacks.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/equipment.png"))); // NOI18N
        Snacks.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 90, 60));

        jLabel10.setFont(new java.awt.Font("Segoe UI Light", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Servicio");
        Snacks.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 100, 60));

        jPanel2.add(Snacks, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 390, 230, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("La Redonda");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 120, 110, 70));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/soccer-ball (1).png"))); // NOI18N
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 130, 140));

        jLabel19.setBackground(new java.awt.Color(102, 51, 0));
        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/d38387c2abc8864480550ea9bcd37893.jpg"))); // NOI18N
        jPanel2.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 420, 170, 210));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/zxzx.jpg"))); // NOI18N
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 80, 180));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/d38387c2abc8864480550ea9bcd37893_1.jpg"))); // NOI18N
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 420, 60, 220));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/zxzx.jpg"))); // NOI18N
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(-190, 0, -1, 180));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/d38387c2abc8864480550ea9bcd37893 5).jpg"))); // NOI18N
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 0, 250, 230));

        jLabel2.setBackground(new java.awt.Color(102, 51, 0));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/d38387c2abc8864480550ea9bcd37893.jpg"))); // NOI18N
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 570));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/d38387c2abc8864480550ea9bcd37893_1.jpg"))); // NOI18N
        jPanel2.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, -60, 60, 690));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/d38387c2abc8864480550ea9bcd37893 (1).jpg"))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 340, 430));

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/d38387c2abc8864480550ea9bcd37893 5).jpg"))); // NOI18N
        jPanel2.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 300, 390, 130));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 550));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/d38387c2abc8864480550ea9bcd37893_1.jpg"))); // NOI18N
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 0, 100, 180));

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel75.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/football-field (1).png"))); // NOI18N
        jPanel5.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 360, 140, 140));

        jLabel76.setFont(new java.awt.Font("Segoe UI Light", 1, 36)); // NOI18N
        jLabel76.setText("CAMPO 2");
        jPanel5.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 180, -1, 60));

        jLabel79.setFont(new java.awt.Font("Segoe UI Light", 1, 36)); // NOI18N
        jLabel79.setText("CAMPO 1");
        jPanel5.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, -1, -1));

        jLabel81.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/football-field (1).png"))); // NOI18N
        jPanel5.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 360, 140, 140));

        jLabel82.setFont(new java.awt.Font("Segoe UI Light", 1, 36)); // NOI18N
        jLabel82.setText("CAMPO 4");
        jPanel5.add(jLabel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 390, -1, 60));

        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 350, 290, 150));

        jLabel83.setText("MESA 1");
        jPanel5.add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 420, -1, -1));

        jLabel84.setFont(new java.awt.Font("Segoe UI Light", 1, 36)); // NOI18N
        jLabel84.setText("CAMPO 2");
        jPanel5.add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 400, -1, 60));

        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 350, 300, 160));

        jLabel77.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/football-field (1).png"))); // NOI18N
        jPanel5.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 140, 140, 150));

        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 130, 300, 160));

        jLabel85.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/football-field (1).png"))); // NOI18N
        jPanel5.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 140, 150));

        jbtnMesa1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnMesa1ActionPerformed(evt);
            }
        });
        jPanel5.add(jbtnMesa1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 300, 170));
        jPanel5.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 1020, 20));

        jLabel86.setFont(new java.awt.Font("Segoe UI Light", 1, 24)); // NOI18N
        jLabel86.setForeground(new java.awt.Color(255, 255, 255));
        jLabel86.setText("Campos Deportivos");
        jPanel5.add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, 230, 50));

        jLabel87.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel87.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/football-field.png"))); // NOI18N
        jPanel5.add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 60, 40));

        jLabel88.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/ddb18728a2772d3228ecaa8e83aa3c63 (1)_1.jpg"))); // NOI18N
        jPanel5.add(jLabel88, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, 540));

        pSnacks.addTab("Mesas", jPanel5);

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel10.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 1020, 20));

        jLabel56.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/lock (1).png"))); // NOI18N
        jPanel10.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 450, 40, 20));

        jLabel15.setFont(new java.awt.Font("Segoe UI Light", 1, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Bebidas");
        jPanel10.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 140, 40));

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/can.png"))); // NOI18N
        jPanel10.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 50, 40));

        jLabel43.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("Pagar");
        jPanel10.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 440, 90, 40));

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/WhatsApp_Image_2023-10-12_at_10.06.42_PM-removebg-preview (2).png"))); // NOI18N
        jPanel10.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 100, 100, 100));

        jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/86564017b7adaaa1786331bf27480db9-removebg-preview (2)_1.png"))); // NOI18N
        jPanel10.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 100, 80, 100));

        jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/WhatsApp_Image_2023-10-12_at_9.57.56_PM__1_-removebg-preview (1).png"))); // NOI18N
        jPanel10.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 250, 30, 100));

        jbtnPagar.setBackground(new java.awt.Color(0, 0, 0));
        jbtnPagar.setForeground(new java.awt.Color(255, 255, 255));
        jbtnPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnPagarActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 440, 300, 40));

        jLabel32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/IncaCola500ml5e46dfd2d5914-removebg-preview (4)_1.png"))); // NOI18N
        jPanel10.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, 130, 100));

        jbtnAgregarInkaCola.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarInkaCola.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarInkaCola.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarInkaCola.setText("Agregar a Cuenta");
        jbtnAgregarInkaCola.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarInkaColaActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnAgregarInkaCola, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 120, -1));

        jLabel17.setBackground(new java.awt.Color(0, 0, 0));
        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel17.setText("S/.3.00");
        jPanel10.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, 60, -1));

        jLabel33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/R__1_-removebg-preview (1)_1.png"))); // NOI18N
        jPanel10.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 100, 130, 100));

        jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/sprite-removebg-preview (3)_2.png"))); // NOI18N
        jPanel10.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 260, 100, 80));

        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 140, 140));

        jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/imgbin-coca-cola-zero-soft-drink-diet-coke-coca-cola-PgBXgvUPi0udda0Z45PS5XcXu_t-removebg-preview (2)_2.png"))); // NOI18N
        jPanel10.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, 130, 120));

        jbtnAgregarSebena.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarSebena.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarSebena.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarSebena.setText("Agregar a Cuenta");
        jbtnAgregarSebena.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarSebenaActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnAgregarSebena, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 210, 120, -1));

        jLabel35.setBackground(new java.awt.Color(0, 0, 0));
        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel35.setText("S/.2.00");
        jPanel10.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 190, 60, -1));

        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, 140, 140));

        jbtnAgregarPepsi.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarPepsi.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarPepsi.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarPepsi.setText("Agregar a Cuenta");
        jbtnAgregarPepsi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarPepsiActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnAgregarPepsi, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 210, 120, -1));

        jLabel21.setBackground(new java.awt.Color(0, 0, 0));
        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel21.setText("S/.2.50");
        jPanel10.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 190, 60, -1));

        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 100, 140, 140));

        jbtnAgregarFanta.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarFanta.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarFanta.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarFanta.setText("Agregar a Cuenta");
        jbtnAgregarFanta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarFantaActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnAgregarFanta, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 210, 120, -1));

        jLabel22.setBackground(new java.awt.Color(0, 0, 0));
        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel22.setText("S/3.00");
        jPanel10.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 190, 60, -1));

        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 100, 140, 140));

        jbtnAgregarCocaCola.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarCocaCola.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarCocaCola.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarCocaCola.setText("Agregar a Cuenta");
        jbtnAgregarCocaCola.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarCocaColaActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnAgregarCocaCola, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 120, -1));

        jLabel23.setBackground(new java.awt.Color(0, 0, 0));
        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel23.setText("S/.3.00");
        jPanel10.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 60, -1));

        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 140, 140));

        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/WhatsApp_Image_2023-10-15_at_7.37.01_PM-removebg-preview (2).png"))); // NOI18N
        jPanel10.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 250, 30, 100));

        jbtnAgregarGuarana.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarGuarana.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarGuarana.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarGuarana.setText("Agregar a Cuenta");
        jbtnAgregarGuarana.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarGuaranaActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnAgregarGuarana, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 360, 120, -1));

        jLabel25.setBackground(new java.awt.Color(0, 0, 0));
        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel25.setText("S/.2.50");
        jPanel10.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 340, 60, -1));

        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 250, 140, 140));

        jbtnAgregarSprite.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarSprite.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarSprite.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarSprite.setText("Agregar a Cuenta");
        jbtnAgregarSprite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarSpriteActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnAgregarSprite, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 360, 120, -1));

        jLabel38.setBackground(new java.awt.Color(0, 0, 0));
        jLabel38.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel38.setText("S/.3.00");
        jPanel10.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 340, 60, -1));

        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 250, 140, 140));

        jbtnAgregarConcordia.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarConcordia.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarConcordia.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarConcordia.setText("Agregar a Cuenta");
        jbtnAgregarConcordia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarConcordiaActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnAgregarConcordia, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 360, 120, -1));

        jLabel40.setBackground(new java.awt.Color(0, 0, 0));
        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel40.setText("S/.1.00");
        jPanel10.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 340, 60, -1));

        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 250, 140, 140));

        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/WhatsApp_Image_2023-10-12_at_11.30.39_PM-removebg-preview (2).png"))); // NOI18N
        jPanel10.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 400, 60, 100));

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cusqueña-roja-Gourmeat-removebg-preview (1)_1.png"))); // NOI18N
        jPanel10.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 400, 80, 100));

        jbtnAgregarSanCarlos.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarSanCarlos.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarSanCarlos.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarSanCarlos.setText("Agregar a Cuenta");
        jbtnAgregarSanCarlos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarSanCarlosActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnAgregarSanCarlos, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, 120, -1));

        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/R__3_-removebg-preview (2)_1.png"))); // NOI18N
        jPanel10.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 410, 80, 80));

        jLabel30.setBackground(new java.awt.Color(0, 0, 0));
        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel30.setText("S/1.00");
        jPanel10.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 490, 60, -1));

        jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/WhatsApp_Image_2023-10-12_at_11.34.28_PM-removebg-preview (2).png"))); // NOI18N
        jPanel10.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 400, 90, 100));

        jLabel46.setFont(new java.awt.Font("Microsoft YaHei", 1, 18)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 255, 255));
        jLabel46.setText("Tu Carrito");
        jPanel10.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 170, 150, 30));

        jLabel47.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel47.setText("Tu Total");
        jPanel10.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 400, 60, -1));

        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, 140, 140));

        jLabel54.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/lock (1).png"))); // NOI18N
        jPanel10.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 450, 40, 20));

        jLabel48.setBackground(new java.awt.Color(0, 0, 0));
        jLabel48.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel48.setText("S/.");
        jPanel10.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 400, 90, 20));

        jtxtTotalPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtTotalPagarActionPerformed(evt);
            }
        });
        jPanel10.add(jtxtTotalPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 400, 170, -1));

        jbtnAgregarCielo.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarCielo.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarCielo.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarCielo.setText("Agregar a Cuenta");
        jbtnAgregarCielo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarCieloActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnAgregarCielo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 510, 120, -1));

        jLabel49.setBackground(new java.awt.Color(0, 0, 0));
        jLabel49.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel49.setText("S/1.50");
        jPanel10.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 490, 60, -1));

        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 400, 140, 140));

        jbtnAgregarCoronita.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarCoronita.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarCoronita.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarCoronita.setText("Agregar a Cuenta");
        jbtnAgregarCoronita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarCoronitaActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnAgregarCoronita, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 510, 120, -1));

        jLabel50.setBackground(new java.awt.Color(0, 0, 0));
        jLabel50.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel50.setText("S/.4.00");
        jPanel10.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 490, 60, -1));

        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 400, 140, 140));

        jbtnAgregarPilsen.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarPilsen.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarPilsen.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarPilsen.setText("Agregar a Cuenta");
        jbtnAgregarPilsen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarPilsenActionPerformed(evt);
            }
        });
        jPanel10.add(jbtnAgregarPilsen, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 510, 120, -1));

        jLabel51.setBackground(new java.awt.Color(0, 0, 0));
        jLabel51.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel51.setText("S/.6.50");
        jPanel10.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 490, 60, -1));

        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 400, 140, 140));

        jtblTabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Bebida", "Cantidad", "P. Unitario", "P. Total"
            }
        ));
        jScrollPane1.setViewportView(jtblTabla);

        jPanel10.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 230, 340, 160));

        jButton16.setBackground(new java.awt.Color(0, 0, 0));
        jPanel10.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 140, 340, 220));
        jPanel10.add(jButton26, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 330, 340, 170));

        jLabel52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/120214fdb6d8969745da38d4ac432adb.jpg"))); // NOI18N
        jPanel10.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 570));

        pSnacks.addTab("Bebidas", jPanel10);

        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbtnAgregarChisito.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarChisito.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarChisito.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarChisito.setText("Agregar a Cuenta");
        jbtnAgregarChisito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarChisitoActionPerformed(evt);
            }
        });
        jPanel16.add(jbtnAgregarChisito, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 240, 120, -1));

        jbtnAgregarCuates.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarCuates.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarCuates.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarCuates.setText("Agregar a Cuenta");
        jbtnAgregarCuates.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarCuatesActionPerformed(evt);
            }
        });
        jPanel16.add(jbtnAgregarCuates, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, 120, -1));

        jbtnAgregarPiqueo.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarPiqueo.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarPiqueo.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarPiqueo.setText("Agregar a Cuenta");
        jbtnAgregarPiqueo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarPiqueoActionPerformed(evt);
            }
        });
        jPanel16.add(jbtnAgregarPiqueo, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 240, 120, -1));

        jbtnAgregarCasino.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarCasino.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarCasino.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarCasino.setText("Agregar a Cuenta");
        jbtnAgregarCasino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarCasinoActionPerformed(evt);
            }
        });
        jPanel16.add(jbtnAgregarCasino, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 410, 120, -1));

        jbtnAgregarLays.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarLays.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarLays.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarLays.setText("Agregar a Cuenta");
        jbtnAgregarLays.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarLaysActionPerformed(evt);
            }
        });
        jPanel16.add(jbtnAgregarLays, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 120, -1));

        jbtnAgregarSublime.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarSublime.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarSublime.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarSublime.setText("Agregar a Cuenta");
        jbtnAgregarSublime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarSublimeActionPerformed(evt);
            }
        });
        jPanel16.add(jbtnAgregarSublime, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 410, 120, -1));

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" }));
        jPanel16.add(jComboBox4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, 120, -1));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" }));
        jPanel16.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 210, 120, -1));

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" }));
        jPanel16.add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 210, 120, -1));

        jButton29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cards.png"))); // NOI18N
        jButton29.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton29, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 140, 140));

        jButton28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/football-shoes.png"))); // NOI18N
        jButton28.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton28, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 130, 140, 140));

        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" }));
        jPanel16.add(jComboBox5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 320, 120, -1));

        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" }));
        jPanel16.add(jComboBox7, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 380, 120, -1));

        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" }));
        jPanel16.add(jComboBox6, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 380, 120, -1));

        jButton31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/ball.png"))); // NOI18N
        jButton31.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton31, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 300, 140, 140));

        jbtnbutton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/gloves.png"))); // NOI18N
        jbtnbutton.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jbtnbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnbuttonActionPerformed(evt);
            }
        });
        jPanel16.add(jbtnbutton, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 130, 140, 140));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" }));
        jPanel16.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 130, -1));

        jButton36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/drills.png"))); // NOI18N
        jButton36.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton36ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton36, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 300, 140, 140));

        jButton35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/football-shirt (1).png"))); // NOI18N
        jButton35.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton35ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton35, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 140, 140));
        jPanel16.add(jtxtTotalPagar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 390, 160, 20));

        jLabel66.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(255, 255, 255));
        jLabel66.setText("Pagar");
        jPanel16.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 430, 40, 40));

        jLabel67.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel67.setText("Tu Total");
        jPanel16.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 390, -1, -1));

        jLabel68.setFont(new java.awt.Font("Microsoft YaHei", 1, 24)); // NOI18N
        jLabel68.setForeground(new java.awt.Color(255, 255, 255));
        jLabel68.setText("Tu Carrito");
        jPanel16.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 180, -1, -1));

        jLabel69.setBackground(new java.awt.Color(0, 0, 0));
        jLabel69.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel69.setText("S/.");
        jPanel16.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 390, 40, 20));

        jtblTabla1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Accesorio", "Cantidad", "P. Unitario", "P. Total"
            }
        ));
        jScrollPane3.setViewportView(jtblTabla1);

        jPanel16.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 230, 290, 140));

        jLabel73.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/lock (1).png"))); // NOI18N
        jPanel16.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 440, 40, 20));

        jbtnPagar1.setBackground(new java.awt.Color(0, 0, 0));
        jbtnPagar1.setForeground(new java.awt.Color(255, 255, 255));
        jbtnPagar1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jbtnPagar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnPagar1ActionPerformed(evt);
            }
        });
        jPanel16.add(jbtnPagar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 430, 280, 40));

        jButton17.setBackground(new java.awt.Color(0, 0, 0));
        jPanel16.add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 170, 290, 190));
        jPanel16.add(jButton27, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 290, 290, 200));
        jPanel16.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 1020, 20));

        jLabel70.setFont(new java.awt.Font("Segoe UI Light", 1, 24)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(255, 255, 255));
        jLabel70.setText("Servicios");
        jPanel16.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 140, 50));

        jLabel71.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/equipment.png"))); // NOI18N
        jPanel16.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 90, 70));

        jLabel72.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/ddb18728a2772d3228ecaa8e83aa3c63 (1)_1.jpg"))); // NOI18N
        jPanel16.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -30, 820, 600));

        jLabel74.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/ddb18728a2772d3228ecaa8e83aa3c63 (1)_1.jpg"))); // NOI18N
        jPanel16.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, 570));

        pSnacks.addTab("Snacks", jPanel16);

        getContentPane().add(pSnacks, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, -40, 820, 580));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BebidasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BebidasMouseClicked
        pSnacks.setSelectedIndex(1);
    }//GEN-LAST:event_BebidasMouseClicked

    private void BebidasMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BebidasMouseMoved
        Bebidas.setBackground(new Color(44, 29, 30));
    }//GEN-LAST:event_BebidasMouseMoved

    private void BebidasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BebidasMouseExited
        Bebidas.setBackground(new Color(12, 20, 11));
    }//GEN-LAST:event_BebidasMouseExited

    private void SnacksMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SnacksMouseClicked
        pSnacks.setSelectedIndex(2);
    }//GEN-LAST:event_SnacksMouseClicked

    private void SnacksMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SnacksMouseMoved
        Snacks.setBackground(new Color(44, 29, 30));
    }//GEN-LAST:event_SnacksMouseMoved

    private void SnacksMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SnacksMouseExited
        Snacks.setBackground(new Color(12, 20, 11));
    }//GEN-LAST:event_SnacksMouseExited

    private void SalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SalirMouseClicked
        dispose();
    }//GEN-LAST:event_SalirMouseClicked

    private void SalirMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SalirMouseMoved
        Salir.setBackground(new Color(44, 29, 30));
    }//GEN-LAST:event_SalirMouseMoved

    private void SalirMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SalirMouseExited
        Salir.setBackground(new Color(12, 20, 11));
    }//GEN-LAST:event_SalirMouseExited

    private void MesasMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MesasMouseMoved
        Mesas.setBackground(new Color(44, 29, 30));
    }//GEN-LAST:event_MesasMouseMoved

    private void MesasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MesasMouseClicked
        pSnacks.setSelectedIndex(0);
    }//GEN-LAST:event_MesasMouseClicked

    private void MesasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MesasMouseExited
        Mesas.setBackground(new Color(12, 20, 11));
    }//GEN-LAST:event_MesasMouseExited

    private void jbtnPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnPagarActionPerformed
        DefaultTableModel model = (DefaultTableModel) jtblTabla.getModel();
        model.setRowCount(0); // Borra todas las filas de la tabla
        Bebida.resetTotalPagar(); // Actualiza el valor del precio total a cero
        jtxtTotalPagar.setText("0.00");
    }//GEN-LAST:event_jbtnPagarActionPerformed

    private void jbtnAgregarInkaColaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarInkaColaActionPerformed
        Bebida inkacola = new InkaCola();
        inkacola.aumentarCantidad();
        agregarBebidaTabla(inkacola);
    }//GEN-LAST:event_jbtnAgregarInkaColaActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jbtnAgregarSebenaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarSebenaActionPerformed
        Bebida sebena = new Sebena();
        sebena.aumentarCantidad();
        agregarBebidaTabla(sebena);
    }//GEN-LAST:event_jbtnAgregarSebenaActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jbtnAgregarPepsiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarPepsiActionPerformed
        Bebida pepsi = new Pepsi();
        pepsi.aumentarCantidad();
        agregarBebidaTabla(pepsi);
    }//GEN-LAST:event_jbtnAgregarPepsiActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jbtnAgregarFantaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarFantaActionPerformed
        Bebida fanta = new Fanta();
        fanta.aumentarCantidad();
        agregarBebidaTabla(fanta);
    }//GEN-LAST:event_jbtnAgregarFantaActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jbtnAgregarCocaColaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarCocaColaActionPerformed
        Bebida cocacola = new CocaCola();
        cocacola.aumentarCantidad();
        agregarBebidaTabla(cocacola);
    }//GEN-LAST:event_jbtnAgregarCocaColaActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jbtnAgregarGuaranaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarGuaranaActionPerformed
        Bebida guarana = new Guarana();
        guarana.aumentarCantidad();
        agregarBebidaTabla(guarana);
    }//GEN-LAST:event_jbtnAgregarGuaranaActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jbtnAgregarSpriteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarSpriteActionPerformed
        Bebida sprite = new Sprite();
        sprite.aumentarCantidad();
        agregarBebidaTabla(sprite);
    }//GEN-LAST:event_jbtnAgregarSpriteActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jbtnAgregarConcordiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarConcordiaActionPerformed
        Bebida concordia = new Concordia();
        concordia.aumentarCantidad();
        agregarBebidaTabla(concordia);
    }//GEN-LAST:event_jbtnAgregarConcordiaActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jbtnAgregarSanCarlosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarSanCarlosActionPerformed
        Bebida sancarlos = new SanCarlos();
        sancarlos.aumentarCantidad();
        agregarBebidaTabla(sancarlos);
    }//GEN-LAST:event_jbtnAgregarSanCarlosActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jtxtTotalPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtTotalPagarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtTotalPagarActionPerformed

    private void jbtnAgregarCieloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarCieloActionPerformed
        Bebida cielo = new Cielo();
        cielo.aumentarCantidad();
        agregarBebidaTabla(cielo);
    }//GEN-LAST:event_jbtnAgregarCieloActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jbtnAgregarCoronitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarCoronitaActionPerformed
        Bebida coronita = new Coronita();
        coronita.aumentarCantidad();
        agregarBebidaTabla(coronita);
    }//GEN-LAST:event_jbtnAgregarCoronitaActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jbtnAgregarPilsenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarPilsenActionPerformed
        Bebida pilsen = new Pilsen();
        pilsen.aumentarCantidad();
        agregarBebidaTabla(pilsen);
    }//GEN-LAST:event_jbtnAgregarPilsenActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jButton15ActionPerformed

    private void jbtnAgregarChisitoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarChisitoActionPerformed
        Comida chisito = new Chisito();
        chisito.aumentarCantidad();
        agregarComidaTabla(chisito);
    }//GEN-LAST:event_jbtnAgregarChisitoActionPerformed

    private void jbtnAgregarCuatesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarCuatesActionPerformed
        Comida cuates = new Cuates();
        cuates.aumentarCantidad();
        agregarComidaTabla(cuates);
    }//GEN-LAST:event_jbtnAgregarCuatesActionPerformed

    private void jbtnAgregarPiqueoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarPiqueoActionPerformed
        Comida piqueo = new Piqueo();
        piqueo.aumentarCantidad();
        agregarComidaTabla(piqueo);
    }//GEN-LAST:event_jbtnAgregarPiqueoActionPerformed

    private void jbtnAgregarCasinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarCasinoActionPerformed
        Comida casino = new Casino();
        casino.aumentarCantidad();
        agregarComidaTabla(casino);
    }//GEN-LAST:event_jbtnAgregarCasinoActionPerformed

    private void jbtnAgregarLaysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarLaysActionPerformed
        Comida lays = new Lays();
        lays.aumentarCantidad();
        agregarComidaTabla(lays);
    }//GEN-LAST:event_jbtnAgregarLaysActionPerformed

    private void jbtnAgregarSublimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarSublimeActionPerformed
        Comida sublime = new Sublime();
        sublime.aumentarCantidad();
        agregarComidaTabla(sublime);
    }//GEN-LAST:event_jbtnAgregarSublimeActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton29ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton31ActionPerformed

    private void jbtnbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnbuttonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnbuttonActionPerformed

    private void jButton36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton36ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton36ActionPerformed

    private void jButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton35ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton35ActionPerformed

    private void jbtnPagar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnPagar1ActionPerformed
        DefaultTableModel model = (DefaultTableModel) jtblTabla1.getModel();
        model.setRowCount(0); // Borra todas las filas de la tabla
        Comida.resetTotalPagar(); // Actualiza el valor del precio total a cero
        jtxtTotalPagar1.setText("0.00");
    }//GEN-LAST:event_jbtnPagar1ActionPerformed

    private void jbtnMesa1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnMesa1ActionPerformed

      Cancha1 mesa1 = new Cancha1(); 
    // Verificar si la mesa está ocupada
    if (!mesa1.isMesaOcupada()) {
        // La mesa no está ocupada, entonces puedes abrirla
        mesa1.setVisible(true);
        dispose();  // Cierra el JFrame actual (Sistema)
    } else {
         jbtnMesa1.setBackground(new Color(44, 29, 30));
        // La mesa está ocupada, mostrar mensaje de error
        JOptionPane.showMessageDialog(this, "La mesa está ocupada.", "Error", JOptionPane.ERROR_MESSAGE);
    }
   

    }//GEN-LAST:event_jbtnMesa1ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        Mesa_3 mesa3 = new Mesa_3();
        if (!mesa3.isMesaOcupada()) {
            Mesa_3 Ini = new Mesa_3();
            Ini.setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "La mesa está ocupada.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Mesa_2 mesa2 = new Mesa_2();
        if (!mesa2.isMesaOcupada()) {
            Mesa_2 Ini = new Mesa_2();
            Ini.setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "La mesa está ocupada.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        Mesa_4 mesa1 = new Mesa_4();
        if (!mesa1.isMesaOcupada()) {
            Mesa_4 Ini = new Mesa_4();
            Ini.setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "La mesa está ocupada.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton3ActionPerformed
    private void agregarBebidaTabla(Bebida bebida) {
        String nombreBebida = bebida.getNombre();
        // Buscar si la bebida ya existe en la tabla
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if (nombreBebida.equals(tableModel.getValueAt(i, 0))) {
                // Si encontramos la bebida, actualizamos cantidad, precio unitario y precio total
                int cantidadActual = (int) tableModel.getValueAt(i, 1);
                double precioUnitario = bebida.getPrecioUnitario();
                cantidadActual++; //Incrementamos la cantidad en lugar de sumar de uno
                double precioTotal = cantidadActual * precioUnitario;

                tableModel.setValueAt(cantidadActual, i, 1); // Incrementamos la cantidad
                tableModel.setValueAt(precioUnitario, i, 2); // Actualizamos el precio unitario
                tableModel.setValueAt(precioTotal, i, 3); // Actualizamos el precio total

                // Actualizamos el JTextField con el nuevo valor de totalPagar
                jtxtTotalPagar.setText(String.valueOf(Bebida.getTotalPagar()));

                return; // Salimos del método ya que la bebida ya fue actualizada
            }
        }

        // Si la bebida no existe, la agregamos como una nueva fila
        tableModel.addRow(new Object[]{nombreBebida, 1, bebida.getPrecioUnitario(), bebida.getPrecioTotal()});

        // Actualizamos el JTextField con el nuevo valor de totalPagar
        jtxtTotalPagar.setText(String.valueOf(Bebida.getTotalPagar()));

    }

    private void agregarComidaTabla(Comida comida) {
        String nombreComida = comida.getNombre();
        // Buscar si la comida ya existe en la tabla
        for (int i = 0; i < tableModelC.getRowCount(); i++) {
            if (nombreComida.equals(tableModelC.getValueAt(i, 0))) {
                // Si encontramos la comida, actualizamos cantidad, precio unitario y precio total
                int cantidadActual = (int) tableModelC.getValueAt(i, 1);
                double precioUnitario = comida.getPrecioUnitario();
                cantidadActual++; //Incrementamos la cantidad en lugar de sumar de uno
                double precioTotal = cantidadActual * precioUnitario;

                tableModelC.setValueAt(cantidadActual, i, 1); // Incrementamos la cantidad
                tableModelC.setValueAt(precioUnitario, i, 2); // Actualizamos el precio unitario
                tableModelC.setValueAt(precioTotal, i, 3); // Actualizamos el precio total

                // Actualizamos el JTextField con el nuevo valor de totalPagar
                jtxtTotalPagar1.setText(String.valueOf(Comida.getTotalPagar()));

                return; // Salimos del método ya que la comida ya fue actualizada
            }
        }

        // Si la comida no existe, la agregamos como una nueva fila
        tableModelC.addRow(new Object[]{nombreComida, 1, comida.getPrecioUnitario(), comida.getPrecioTotal()});

        // Actualizamos el JTextField con el nuevo valor de totalPagar
        jtxtTotalPagar1.setText(String.valueOf(Comida.getTotalPagar()));

    }

    public static void main(String args[]) {

        FlatLightLaf.setup();
        UIManager.put("Button.arc", 50);
        UIManager.put("TextComponent.arc", 50);

        java.awt.EventQueue.invokeLater(new Runnable() {
             public void run() {
             
            
           new Sistema().setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Bebidas;
    private javax.swing.JPanel Mesas;
    private javax.swing.JPanel Salir;
    private javax.swing.JPanel Snacks;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JButton jbtnAgregarCasino;
    private javax.swing.JButton jbtnAgregarChisito;
    private javax.swing.JButton jbtnAgregarCielo;
    private javax.swing.JButton jbtnAgregarCocaCola;
    private javax.swing.JButton jbtnAgregarConcordia;
    private javax.swing.JButton jbtnAgregarCoronita;
    private javax.swing.JButton jbtnAgregarCuates;
    private javax.swing.JButton jbtnAgregarFanta;
    private javax.swing.JButton jbtnAgregarGuarana;
    private javax.swing.JButton jbtnAgregarInkaCola;
    private javax.swing.JButton jbtnAgregarLays;
    private javax.swing.JButton jbtnAgregarPepsi;
    private javax.swing.JButton jbtnAgregarPilsen;
    private javax.swing.JButton jbtnAgregarPiqueo;
    private javax.swing.JButton jbtnAgregarSanCarlos;
    private javax.swing.JButton jbtnAgregarSebena;
    private javax.swing.JButton jbtnAgregarSprite;
    private javax.swing.JButton jbtnAgregarSublime;
    private javax.swing.JButton jbtnMesa1;
    private javax.swing.JButton jbtnPagar;
    private javax.swing.JButton jbtnPagar1;
    private javax.swing.JButton jbtnbutton;
    private javax.swing.JTable jtblTabla;
    private javax.swing.JTable jtblTabla1;
    private javax.swing.JTextField jtxtTotalPagar;
    private javax.swing.JTextField jtxtTotalPagar1;
    private javax.swing.JTabbedPane pSnacks;
    // End of variables declaration//GEN-END:variables
}
