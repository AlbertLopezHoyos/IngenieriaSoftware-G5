package Modelo;

public class Cliente {
       private String nombre ;
        private String celular ;
       private  String dni ;
       private String mes ;
       private String dia ;
       private String año ;

    public Cliente(String nombre, String celular, String dni, String mes, String dia, String año) {
        this.nombre = nombre;
        this.celular = celular;
        this.dni = dni;
        this.mes = mes;
        this.dia = dia;
        this.año = año;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getAño() {
        return año;
    }

    public void setAño(String año) {
        this.año = año;
    }
        
}
