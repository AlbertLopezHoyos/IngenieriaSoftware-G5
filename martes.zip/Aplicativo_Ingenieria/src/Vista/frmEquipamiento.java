
package Vista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class frmEquipamiento extends javax.swing.JFrame {

    private DefaultTableModel modeloTabla;
    private String[] nombresArticulos = {"Botines", "Guantes", "Canilleras", "Polos", "Tarjetas", "Medias"};
    private JComboBox<String>[] jcbxs; // Declaración sin inicialización
    private JButton[] jbtnAgregars; // Declaración sin inicialización
    
    public frmEquipamiento() {
        initComponents();
    jcbxs = new JComboBox[]{jcbx1, jcbx2, jcbx3, jcbx4, jcbx5, jcbx6};
        jbtnAgregars = new JButton[]{jbtnAgregar1, jbtnAgregar2, jbtnAgregar3, jbtnAgregar4, jbtnAgregar5, jbtnAgregar6};

        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Artículo");
        modeloTabla.addColumn("Cantidad");
        modeloTabla.addColumn("Precio U.");
        modeloTabla.addColumn("Precio T.");
        jtblCarrito.setModel(modeloTabla);

        // ActionListener para cada botón
        for (int i = 0; i < nombresArticulos.length; i++) {
            int indiceArticulo = i; 

            jbtnAgregars[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    agregarAlCarrito(nombresArticulos[indiceArticulo], jcbxs[indiceArticulo]);
                }
            });
        }
    }
    
   private void agregarAlCarrito(String articulo, JComboBox<String> comboboxCantidad) {
        String cantidadStr = comboboxCantidad.getSelectedItem().toString();

        if (cantidadStr.equals("<<seleccione>>")) {
            JOptionPane.showMessageDialog(this, "Por favor, selecciona una cantidad.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int cantidad = Integer.parseInt(cantidadStr);
        double precioUnitario = 2.0;
        double precioTotal = cantidad * precioUnitario;

        modeloTabla.addRow(new Object[]{articulo, cantidad, precioUnitario, precioTotal});

        calcularTotal();

        // Restablecer el combobox a la opción por defecto después de agregar
        comboboxCantidad.setSelectedIndex(0);
    }

    private void calcularTotal() {
        double total = 0.0;
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            total += (double) modeloTabla.getValueAt(i, 3); // Columna "Precio T."
        }
        jtxtTotalPagar.setText("S/. " + String.format("%.2f", total));
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel47 = new javax.swing.JLabel();
        jtxtTotalPagar = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        pEquipamiento = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jcbx6 = new javax.swing.JComboBox<>();
        jcbx1 = new javax.swing.JComboBox<>();
        jcbx2 = new javax.swing.JComboBox<>();
        jcbx3 = new javax.swing.JComboBox<>();
        jcbx4 = new javax.swing.JComboBox<>();
        jcbx5 = new javax.swing.JComboBox<>();
        jbtnAgregar4 = new javax.swing.JButton();
        jButton47 = new javax.swing.JButton();
        jbtnAgregar3 = new javax.swing.JButton();
        jButton48 = new javax.swing.JButton();
        jbtnAgregar1 = new javax.swing.JButton();
        jButton49 = new javax.swing.JButton();
        jbtnAgregar2 = new javax.swing.JButton();
        jButton50 = new javax.swing.JButton();
        jbtnAgregarLays8 = new javax.swing.JButton();
        jbtnAgregar6 = new javax.swing.JButton();
        jButton52 = new javax.swing.JButton();
        jbtnAgregar5 = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        jButton51 = new javax.swing.JButton();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jtxtTotalPagar1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtblCarrito = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel30 = new javax.swing.JLabel();

        jLabel47.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel47.setText("Tu Total");

        jtxtTotalPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtTotalPagarActionPerformed(evt);
            }
        });

        jLabel48.setBackground(new java.awt.Color(0, 0, 0));
        jLabel48.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel48.setText("S/.");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pEquipamiento.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/soccer-boots.png"))); // NOI18N
        pEquipamiento.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, 80, 80));

        jLabel33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/soccer-boots.png"))); // NOI18N
        pEquipamiento.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 80, 80));

        jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/gloves (1).png"))); // NOI18N
        pEquipamiento.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 80, 80, 60));

        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/soccer (2).png"))); // NOI18N
        pEquipamiento.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 70, 80, 80));

        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/football-shirt (2).png"))); // NOI18N
        pEquipamiento.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 276, 60, 80));

        jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/red-card.png"))); // NOI18N
        pEquipamiento.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 280, 80, 80));

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/football-long-socks-with-white-lines (1).png"))); // NOI18N
        pEquipamiento.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 280, 80, 70));

        jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/football-long-socks-with-white-lines (1).png"))); // NOI18N
        pEquipamiento.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 290, 80, 70));

        jcbx6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "++" }));
        pEquipamiento.add(jcbx6, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 370, -1, -1));

        jcbx1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "++" }));
        pEquipamiento.add(jcbx1, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 160, -1, -1));

        jcbx2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "++" }));
        pEquipamiento.add(jcbx2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 160, -1, -1));

        jcbx3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "++" }));
        pEquipamiento.add(jcbx3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 160, -1, -1));

        jcbx4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "++" }));
        pEquipamiento.add(jcbx4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 370, -1, -1));

        jcbx5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<seleccione>>", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "++" }));
        pEquipamiento.add(jcbx5, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 370, -1, -1));

        jbtnAgregar4.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregar4.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregar4.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregar4.setText("Agregar al carrito");
        jbtnAgregar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregar4ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jbtnAgregar4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, 120, 20));

        jButton47.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton47ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jButton47, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 140, 170));

        jbtnAgregar3.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregar3.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregar3.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregar3.setText("Agregar al carrito");
        jbtnAgregar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregar3ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jbtnAgregar3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 190, 120, 20));

        jButton48.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton48ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jButton48, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 50, 140, 170));

        jbtnAgregar1.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregar1.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregar1.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregar1.setText("Agregar al carrito");
        jbtnAgregar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregar1ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jbtnAgregar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, 120, 20));

        jButton49.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton49ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jButton49, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 140, 170));

        jbtnAgregar2.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregar2.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregar2.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregar2.setText("Agregar al carrito");
        jbtnAgregar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregar2ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jbtnAgregar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 190, 120, 20));

        jButton50.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton50ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jButton50, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 50, 140, 170));

        jbtnAgregarLays8.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregarLays8.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregarLays8.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregarLays8.setText("Agregar al carrito");
        jbtnAgregarLays8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregarLays8ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jbtnAgregarLays8, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 180, 120, 20));

        jbtnAgregar6.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregar6.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregar6.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregar6.setText("Agregar al carrito");
        jbtnAgregar6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregar6ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jbtnAgregar6, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 400, 120, 20));

        jButton52.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton52ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jButton52, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 260, 140, 170));

        jbtnAgregar5.setBackground(new java.awt.Color(0, 0, 0));
        jbtnAgregar5.setFont(new java.awt.Font("Mongolian Baiti", 0, 12)); // NOI18N
        jbtnAgregar5.setForeground(new java.awt.Color(255, 255, 255));
        jbtnAgregar5.setText("Agregar al carrito");
        jbtnAgregar5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgregar5ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jbtnAgregar5, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 400, 120, 20));

        jLabel31.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("Tu Carrito");
        pEquipamiento.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 95, 90, 40));

        jButton51.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton51ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jButton51, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, 140, 170));

        jLabel49.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel49.setText("Tu Total");
        pEquipamiento.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 310, 60, -1));

        jLabel50.setBackground(new java.awt.Color(0, 0, 0));
        jLabel50.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel50.setText("S/.");
        pEquipamiento.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 310, 20, 20));

        jtxtTotalPagar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtTotalPagar1ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jtxtTotalPagar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 310, 130, -1));

        jtblCarrito.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Articulo", "Cantidad", "Precio U.", "Precio T."
            }
        ));
        jScrollPane1.setViewportView(jtblCarrito);

        pEquipamiento.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 140, 270, 200));

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        pEquipamiento.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 90, 270, 130));

        jButton3.setBackground(new java.awt.Color(0, 0, 0));
        jButton3.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Enviar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        pEquipamiento.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 350, 230, -1));
        pEquipamiento.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 260, 270, 130));

        jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Vista/ddb18728a2772d3228ecaa8e83aa3c63.jpg"))); // NOI18N
        pEquipamiento.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(-330, -40, 1170, 510));

        getContentPane().add(pEquipamiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnAgregar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregar4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnAgregar4ActionPerformed

    private void jButton47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton47ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton47ActionPerformed

    private void jbtnAgregar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregar3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnAgregar3ActionPerformed

    private void jButton48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton48ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton48ActionPerformed

    private void jbtnAgregar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnAgregar1ActionPerformed

    private void jButton49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton49ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton49ActionPerformed

    private void jbtnAgregar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregar2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnAgregar2ActionPerformed

    private void jButton50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton50ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton50ActionPerformed

    private void jbtnAgregarLays8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregarLays8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnAgregarLays8ActionPerformed

    private void jbtnAgregar6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregar6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnAgregar6ActionPerformed

    private void jButton52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton52ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton52ActionPerformed

    private void jbtnAgregar5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgregar5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnAgregar5ActionPerformed

    private void jButton51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton51ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton51ActionPerformed

    private void jtxtTotalPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtTotalPagarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtTotalPagarActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jtxtTotalPagar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtTotalPagar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtTotalPagar1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmEquipamiento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmEquipamiento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmEquipamiento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmEquipamiento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmEquipamiento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton47;
    private javax.swing.JButton jButton48;
    private javax.swing.JButton jButton49;
    private javax.swing.JButton jButton50;
    private javax.swing.JButton jButton51;
    private javax.swing.JButton jButton52;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbtnAgregar1;
    private javax.swing.JButton jbtnAgregar2;
    private javax.swing.JButton jbtnAgregar3;
    private javax.swing.JButton jbtnAgregar4;
    private javax.swing.JButton jbtnAgregar5;
    private javax.swing.JButton jbtnAgregar6;
    private javax.swing.JButton jbtnAgregarLays8;
    private javax.swing.JComboBox<String> jcbx1;
    private javax.swing.JComboBox<String> jcbx2;
    private javax.swing.JComboBox<String> jcbx3;
    private javax.swing.JComboBox<String> jcbx4;
    private javax.swing.JComboBox<String> jcbx5;
    private javax.swing.JComboBox<String> jcbx6;
    private javax.swing.JTable jtblCarrito;
    private javax.swing.JTextField jtxtTotalPagar;
    private javax.swing.JTextField jtxtTotalPagar1;
    private javax.swing.JPanel pEquipamiento;
    // End of variables declaration//GEN-END:variables
}
